import type { AnyNode } from "domhandler";
import type { Selector } from "css-what";
export declare function getDocumentRoot(node: AnyNode): AnyNode;
export declare function groupSelectors(selectors: Selector[][]): [plain: Selector[][], filtered: Selector[][]];
//# sourceMappingURL=helpers.d.ts.map