export default function isLayoutViewport(): boolean;
