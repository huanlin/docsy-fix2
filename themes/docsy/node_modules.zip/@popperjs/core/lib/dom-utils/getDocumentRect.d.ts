import type { Rect } from "../types";
export default function getDocumentRect(element: HTMLElement): Rect;
